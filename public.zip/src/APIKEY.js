
module.exports = {
  APIKey: '1194cb54'
};